function valores() {
    var number = document.getElementsByName("numero");
    var selecionado = document.querySelector("#quantidade");
    selecionado.addEventListener("change", (el) => {
        if (selecionado.checked) {
            do {

            } while ()
        }
    })

}