//funcao calcula

function calcula(){
    var num1 = 0;
    var num2 = 5;

    document.write(num1+num2);
}