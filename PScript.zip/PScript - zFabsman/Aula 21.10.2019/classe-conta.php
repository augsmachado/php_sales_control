
<?php

	class Conta{
		public $agencia;
		public $saldo;
		
		public function imprimirSaldo(){
			echo "<br/> O saldo é R$ ".$this->saldo;
		}
	}
?>