<?php
	
	include("classe-conta.php");

	$objconta = new Conta();
	
	$objconta->agencia = 1234;
	$objconta->saldo = 1250.00;
	
	$objconta->imprimirSaldo();
?>