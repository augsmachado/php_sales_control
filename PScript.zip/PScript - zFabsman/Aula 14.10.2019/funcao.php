<?php

//Criação Função s/ parametros
function soma(){
    $soma = 1 + 2;
    echo $soma;
}

soma(); //Chamada da Função


//Criação Função c/ parametros
function soma_para($num1, $num2){
    $soma = $num1 + $num2;
    echo $soma;
}

soma_para(1, 2); //Chamada da Função


//Criação Função c/ return
function retorna_data(){
    $agora = time();
    return $agora;
}

$hoje = retorna_data(); //Chamada da Função
echo retorna_data(); //Chamada da Função


//Criação Função Recursiva
function recursiva($valor){
    if($valor != 0){
        echo "Função valor $valor";
        recursiva($valor - 1);
    }
}

recursiva(7); //Chamada da Função
?>