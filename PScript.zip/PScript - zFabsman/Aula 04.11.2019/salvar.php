<?php include("config.php");?>
<?php

    $contato = new Contato();

    $contato->setNome($_POST["nome"]);
    $contato->setEmail($_POST["email"]);
    $contato->setMensagem($_POST["mensagem"]);

    $add = $contato->salvar($conexao, $contato->getNome(), $contato->getEmail(), $contato->getMensagem());

    if($add == 1) echo("Êxito. Os dados foram adicionados.");
    else echo("Falha. Os dados não foram adicionados.");

    $sql = mysqli_query($conexao, "Select * from contato");
    
    while($linha = mysqli_fetch_array($sql)){
        $contato->setNome($linha["nome"]);
        $contato->setEmail($linha["email"]);
        $contato->setMensagem($linha["mensagem"]);
    }
?>