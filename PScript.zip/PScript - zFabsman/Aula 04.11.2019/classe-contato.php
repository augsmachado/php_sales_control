<?php

    class Contato{
        public $id;
        public $nome;
        public $email;
        public $mensagem;

        public function setNome($nome){
            $this->nome = $nome;
        }

        public function getNome(){
            return $this->nome;
        }

        public function setEmail($email){
            $this->email = $email;
        }

        public function getEmail(){
            return $this->email;
        }

        public function setMensagem($mensagem){
            $this->mensagem = $mensagem;
        }

        public function getMensagem(){
            return $this->mensagem;
        }

        public function salvar($conexao, $nome, $email, $msg){
            mysqli_query($conexao, "insert into contato (nome, email, mensagem) value ('$nome', '$email', '$msg')") or print(mysqli_error());
        }

        public function listar($sql, $conexao){
            mysqli_query($conexao, "Select * from contato");
        
            while($linha = mysqli_fetch_array($sql)){
                $contato->setNome($linha["nome"]);
                $contato->setEmail($linha["email"]);
                $contato->setMensagem($linha["mensagem"]);
            }
        }
    }

?>