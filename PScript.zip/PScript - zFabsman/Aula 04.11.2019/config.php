<?php

	$host = "localhost";
	$usuario = "";
	$senha = "";
	$bd = "contato";
	
	$conexao = mysqli_connect($host,$usuario,
	$senha,$bd) or die ("Não foi possível
	conectar");

	if($conexao == 1) echo("Inserido com sucesso.");

?>