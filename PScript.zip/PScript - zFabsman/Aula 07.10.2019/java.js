function add() {
    var select = document.getElementById("lista");
    var valor = document.getElementById("valor");

    var option = new Option(valor, valor);
    select.add(option);
}