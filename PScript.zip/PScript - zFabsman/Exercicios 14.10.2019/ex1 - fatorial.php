<?php
// Crie uma função que calcule o fatorial de um número

function fatorial($valor){
    if($valor <= 1) return 1;

    else{
        $total = $valor * fatorial($valor - 1);
        return = total
    }

    echo fatorial(4);
    echo "\n";
}

/*Crie uma função que faça a conversão entre as temperaturas Celsiues e Fatenheit
A função recebe por parametros a temperatura e a indicação de F para Farenheit e C para Celcius
Depois */
?>