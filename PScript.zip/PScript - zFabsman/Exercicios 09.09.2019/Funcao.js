/*<!--Crie 3 Funções em JavaScript

1) Uma que receba 4 números e verifique o maior deles.
2) Receba a base e a altura e calcula a área de um triângulo.
3) Receba um cor e altere  cor do fundo da página de acordo com a cor informada.-->*/

function maior() {
    var max = 0;
    var num1 = prompt("Digite um número");
    var num2 = prompt("Digite mais um número");
    var num3 = prompt("Digite outro número");
    var num4 = prompt("Digite o ultimo número");

    max = num1;
    if (max < num2) max = num2;
    if (max < num3) max = num3;
    if (max < num4) max = num4;

    document.write(max);
}