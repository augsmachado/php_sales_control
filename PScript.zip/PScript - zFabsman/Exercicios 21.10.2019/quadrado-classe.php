<?php
	
	class Quadrado{
		public $tamanho;
		public $area;
		
		public function mudarTamanho($tamanho){
			$this->tamanho = tamanho;
			$this->area = tamanho * tamanho;

		}
		
		public function retornaTamanho(){
			echo "Tamanho: $this->tamanho";
			return $this->tamanho;
		}
		
		public function calcularArea(){
			echo "A área do quadrado atualmente é: $this->area";
		}
	}
?>