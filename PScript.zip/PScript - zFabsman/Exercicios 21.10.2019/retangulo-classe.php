<?php

    class Retangulo{
        public $base;
        public $altura;

        public function mudarValores($base, $altura){
            $this->base = $base;
            $this->altura = $altura;
        }

        public function retornarValores(){
            echo "A base é: $this->base<br>A altura é: $this->altura";
        }

        public function calcularArea(){
            echo "A área atual é: ".$this->base * $this->altura;
        }

        public function calcularPerimetro(){
            echo "O perímetro atual é: ".($this->base * 2) + ($this->altura * 2);
        }


    }

?>