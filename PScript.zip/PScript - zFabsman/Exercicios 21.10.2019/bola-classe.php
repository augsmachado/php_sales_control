<?php
	
	class Bola{
		public $cor;
		public $circunferencia;
		public $material;
		
		public function trocaCor($cor){
			$this->cor = $cor;
		}
		public function mostraCor(){
			echo "<br/>Cor: $this->cor";
		}
	}
?>