<?php

    include("retangulo-classe.php");
    $objretangulo = new Retangulo();

    $objretangulo->base = 22;
    $objretangulo->altura = 10;

    $objretangulo->retornarValores();
    $objretangulo->mudarValores(15, 35);

    $objretangulo->retornarValores();

?>