<?php
	include("classe-bola.php");
	
	$objbola = new Bola();
	
	$objbola -> cor = "Laranja";
	$objbola -> circunferencia = 50;
	$objbola -> material = "couro";
	$objbola -> mostraCor();
	
	$objbola -> trocaCor("Azul");
	$objbola -> mostraCor();
	
?>