<?php
	
	include("classe-quadrado.php");
	
	$objquadrado = new Quadrado();
	
	$objquadrado->tamanho = 15;
	$objquadrado->retornaTamanho();
	$objquadrado->calcularArea();
	$objquadrado->mudarTamanho(20);
	
	$objquadrado->retornaTamanho();
	$objquadrado->calcularArea();
	
?>