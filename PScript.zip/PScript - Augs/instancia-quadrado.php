<?php
	include("classe-quadrado.php");

	$quad = new Quadrado();

	$quad->tamLado = 4;

	$quad->valorLado();
	$quad->mudarValorLado(8);

	$quad->valorLado();
	$quad->valorArea($quad->tamLado);
?>