<?php  

$servidor='127.0.0.1';
$usuario='root';
$senha='';
$bancoDados='atividade1610';

$conexão=mysqli_connect( $servidor, $usuario, $senha, $bancoDados);

if (mysqli_connect_errno($conexão)){
	
echo "Problema para conectar no banco.";}

 else {
	echo "conexão realizada com sucesso.";
}



?>