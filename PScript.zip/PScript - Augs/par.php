</!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php
$numero=$_GET["campo1"];
  if($numero % 2 == 0)
  {
  	echo "Par";
  }
  else
  {
  	echo "Impar";
  }

?>

</body>
</html>>