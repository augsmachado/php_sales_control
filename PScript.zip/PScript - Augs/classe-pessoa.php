<?php
	class Pessoa {
		public $nome;
		public $idade;
		public $peso;
		public $altura;

		public function envelhecer(){
			$this->idade += 1;
			echo "<br/>$this->nome, voce possui $this->idade anos";
		}

		public function engordar(){
			$this->peso += 3;
			echo "<br/>$this->nome, voce engordou :( <br/>Peso atual: $this->peso";
		}

		public function emagrecer(){
			$this->peso -= 0.5;
			echo "<br/>Voce emagreceu :) <br/>Peso atual: $this->peso";
		}

		public function crescer($idade){
			if($idade > 0 && $idade < 21){
				$this->altura = $idade * 5;
			} else if ($idade > 21) {
				$this->altura = ($idade - 21) * 5;
			}

			echo "<br/>$this->nome sua altura é $this->altura cm";
		}
	}
?>