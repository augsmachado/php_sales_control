<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<?php

	$a=1;
	$b=2;
	$c=3;

	if ($a<$b)
		 {
		 
		 		echo "$a $b $c";
		 	}
				
	?>

</body>
</html>