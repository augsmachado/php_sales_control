<?php
	function conversor($tipo, $valor)
	{
		if ($tipo == "C")
		{
			$temp = ($valor - 32) * (9/5);
			echo "$temp F";
		}
		else if ($tipo == "F")
		{
			$temp = ($valor * (9/5)) + 32;
			echo "$temp C";
		}
	}

	conversor(F, 72);
	conversor(C, 0);

?>