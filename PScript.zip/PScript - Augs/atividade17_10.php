<?php
$servidor='127.0.0.1';
$usuario='root';
$senha='';
$bancoDados='atividade1610';

$conexao=mysqli_connect($servidor, $usuario, $senha, $bancoDados);

if (!$conexao) 
{
	die("Conection failed: " . mysqli_connect_error());
}
echo "Conectede successfully: <br>";
$nome=$_POST['nome'];
$sobrenome=$_POST['sobrenome'];
$email=$_POST['email'];



$sql = "INSERT INTO estudante (nome, sobrenome, email) VALUES ('$nome', '$sobrenome', '$email')";

if (mysqli_query($conexao, $sql)) 
{
	echo "Novas informações inseridas";
	
}
else
{ 
	echo "Error: " . $sql . "<br>" . mysqli_error($conexao);	
}
mysqli_close($conexao)	


?>