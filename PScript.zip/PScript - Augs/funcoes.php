<?php

//funcao sem parametros
function soma()
{
	$soma = 1 + 2;
	echo $soma;
}
soma();

//funcao com paramentros
function soma_param($num1, $num2)
{
	$soma = $num1+$num2;
	echo $soma;
}
soma_param(2,3);

// funcao com retorno
function retorna_data()
{
	$agora = time();
	return $agora;
}
$hoje = retorna_data(); //ou
echo retorna_data();

// funcao recursiva
function recursiva($valor)
{
	if(valor != 0)
	{
		echo "Função valor $valor";
		recursiva($valor-1);
	}
}
recursiva(7);





?>