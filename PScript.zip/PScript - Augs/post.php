</!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php
echo "O valor de CAMPO 1 é: " . $_POST["campo1"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["campo2"];
?>

</body>
</html>>