<?php
	class Quadrado{
		public $tamLado;

		public function mudarValorLado($novo){
			$this->tamLado = $novo;
		}

		public function valorLado(){
			echo "<br/>Valor do lado: $this->tamLado";
		}

		public function valorArea(){
			$area = $this->tamLado * $this->tamLado;
			echo "<br/>Area: $area";
		}
	}

?>