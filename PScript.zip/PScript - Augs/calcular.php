<?php
	$total=0;
	if(isset($_POST["lista"]))
	{
		$lista=$_POST["lista"];

		for($i=0; $i<count($lista); $i++){
			$total += $lista[$i];
		}
		$media = $total(count($lista));

		echo "Média = $media";
	}
?>