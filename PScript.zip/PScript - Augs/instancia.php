<?php
	include("conta.php");

	$objconta = new Conta();
	$objconta->agencia = 1234;
	$objconta->saldo = 1250.00;

	$objconta->imprimirSaldo($objconta->saldo);

	echo "<br/> Agencia: $objconta->agencia";

?>