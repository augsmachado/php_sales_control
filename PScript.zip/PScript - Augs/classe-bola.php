<?php
	class Bola{
		public $cor;
		public $circuferencia;
		public $material;

		public function trocaCor(){
			echo "<br/>A nova cor é: $this->cor";
		}

		public function mostraCor(){
			echo "<br/>Cor: $this->cor";
		}
	}
?>