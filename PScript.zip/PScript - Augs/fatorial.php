<?php
	funtion fatorial($valor)
	{
		if ($valor == 0)
		{
			return 1;
		}
		return ($valor * ($valor-1));
	}

	fatorial(3);


?>