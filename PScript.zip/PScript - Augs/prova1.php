<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
	$num=1000;

	echo "escreva um numero: $num <br>";

	
		if ($num==1) {
			echo "janeiro";
			# code...
		}
		elseif ($num==2) {
			echo "fevereiro";
			# code...
		}
		elseif ($num==3) {
			echo "marco";
			# code...
		}
		elseif ($num==4) {
			echo "abril";
			# code...
		}
		elseif ($num==5) {
			echo "maio";
			# code...
		}
		elseif ($num==6) {
			echo "junho";
			# code...
		}
		elseif ($num==7) {
			echo "julho";
			# code...
		}
		elseif ($num==8) {
			echo "agosto";
			# code...
		}
		elseif ($num==9) {
			echo "setembro";
			# code...
		}
		elseif ($num==10) {
			echo "outubro";
			# code...
		}
		elseif ($num==11) {
			echo "novembro";
			# code...
		}
		elseif ($num==12) {
			echo "dezembro";
			# code...
		}
		elseif ($num<=0) {
			echo "nao existe";
			# code...
		}
		elseif ($num>=13) {
			echo "nao existe";
			# code...
		}

		
		
	
	
	
 ?>

</body>
</html>