<!doctype html>

<html>
<head>
	<title> Aula Form </title>
	<meta chaset="UTF-8"
</head>
<body>
	<?php

		// comando de saida
		echo "Hello World! --> echo <br>";
		print("Hello World --> print <br>");

		// declaracao de variavel
		$nome = "jhon";
		echo $nome;

		$sobrenome ="leite nodente";
		echo "<br>$sobrenome, $nome<br>";

		// ponteiros
		$a = 5;
		$b = &$a;
		$b = 10;

		echo "Imprimindo ponteiro: $a <br>";
		echo $b;

		// vetores
		$arr = array(5,30,40,20);
		echo "<br>Imprimindo uma posicao do array => $arr[0]<br>";
		print_r($arr);

		// matrizes
		$matriz=array(1,2,array("carlos", array(7,9)), "xa");
		print_r($matriz);
		echo "<br>Imprimindo valor da posicao na matriz: $matriz[2][0]<br>";


		echo "<br>";
		//exercicio
		$a = 10;
		$b = 20;
		$aux;
		echo "A: $a 	B: $b<br>";

		$aux = $a;
		$a = $b;
		$b = $aux;
		echo "A: $a 	B: $b<br>"


	?>
</body>
</html>