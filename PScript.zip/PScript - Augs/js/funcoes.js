//funcao calcula
function calcula (){
	var num1 = 0;
	var num2 = 5;
	
	document.write(num1 + num2);
}

function maior ()
{
	var num1 = prompt("Digite o primeiro valor");
	var num2 = prompt("Digite o segundo valor");
	var num3 = prompt("Digite o terceiro valor");
	var num4 = prompt("Digite o quarto valor");

	if (num1 > num2 && num1 > num3 && num1 > num4)
	{
		document.write(num1);
	}
	if (num2 > num1 && num2 > num3 && num2 > num4)
	{
		document.write(num2);
	}
	if (num3 > num1 && num3 > num2 && num3 > num4)
	{
		document.write(num3);
	}
	if (num4 > num1 && num4 > num2 && num4 > num3)
	{
		document.write(num4);
	}
}

function areaTriangulo (){
	var base = prompt("Digite o valor da base do triangulo\n");
	var altura = prompt("Digite o valor da altura do triangulo\n");
	
	document.write("Area do triagulo: " + ((base*altura)/2)+"\n");
}

function corFundo () {
	var cor = prompt("Digite o nome da nova cor de fundo\n");
	document.bgColor = cor;
}