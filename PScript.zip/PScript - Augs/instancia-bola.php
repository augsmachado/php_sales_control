<?php
	include("classe-bola.php");

	$objbola = new Bola();

	$objbola->cor = 'azul';
	$objbola->circunferencia = 32.00;
	$objbola->material = "couro";

	$objbola->mostraCor();
	
	$objbola->cor = 'amarelo';
	$objbola->trocaCor();

?>