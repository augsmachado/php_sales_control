<?php
$servidor='127.0.0.1';
$usuario='root';
$senha='';
$bancoDados='atividade1610';

$conexao=mysqli_connect($servidor, $usuario, $senha, $bancoDados);

if (mysqli_connect_errno($conexao)) {
	echo "Problema para conectar no banco";
}
else{ echo "Conexão realizada com sucesso";

	# code...
	}


?>