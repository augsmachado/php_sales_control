<?php
	include("classe-pessoa.php");

	$persona = new Pessoa();

	$persona->nome = "Maria Frascisco da Serra da Costela";
	$persona->idade = 20;
	$persona->peso = 55;

	$persona->crescer($persona->idade);
	$persona->emagrecer();
	$persona->engordar();
	$persona->envelhecer();
?>