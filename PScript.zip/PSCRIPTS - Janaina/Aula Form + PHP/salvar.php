<?php include 'config.php';?>
<?php include 'classe-Contato.php';?>
<?php

	$contato = new Contato();
	
	$contato->setNome($_POST["nome"]);
	$contato->setEmail($_POST["email"]);
	$contato->setMensagem($_POST["mensagem"]);
	
	$add= $contato->salvar($conexao, 
	$contato->getNome(),$contato->getEmail(),
	$contato->getMensagem());
	
	if($add==1)
		echo 'Ok!';
	Else
		echo 'Erro, tente novamente';	
	
	/*exemplo do método listar
	$sql = mysqli_query($conexao, 
	"Select * from contato");
	while ($linha = mysqli_fetch_array($sql))
	{
		$contato->setNome($linha["nome"]);
		$contato->setEmail($linha["email"]);
	}
	*/
	
	
?>