<?php

$host = "localhost";
$usuario = "";
$senha = "";
$db = "contato";

$conexao = mysqli_connect($host, $usuario, $senha, $db) or die ("Não deu bom pra conectar");



?>