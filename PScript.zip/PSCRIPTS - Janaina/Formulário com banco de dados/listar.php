<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <title>Formulário de contato</title>
</head>
<body>
	<?php include 'config.php';?>
	<?php include 'classe-contato.php';?>
		
		  <h2>Contato</h2>
		  <p> Listando contatos</p>
		  		  
		  <?php	
			
			$contato = new Contato();
			
			$sql=contato->listar($conexao);
				while($linha = mysqli_fetch_array($sql)){						
						$contato->setid($linha["id"]);
						$contato->setNome($linha["nome"]);
						$contato->setEmail($linha["email"]);
						$contato->setMensagem($linha["mensagem"]);
						
						echo "<hr> 
							
							  Id: $contato->getId() <br>
							  Nome: $contato->getNome() <br>
						      e-mail: $contato->getEmail() <br>							  
							  Mensagem: $contato->getMensagem()
							  
							  <a title='Excluir' href='excluir.php?id=$id'>Excluir</a>
							  <a title='Editar' href='index.php?id=$id&acao=editar'>Editar</a>";  
				}				
		?>
		

</body>
</html>
