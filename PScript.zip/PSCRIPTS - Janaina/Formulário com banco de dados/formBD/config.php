<?php
    $host = "localhost";
    $usuario = "root";
    $senha = "";
    $bd = "bd01_scripts";

    $conexao = mysqli_connect($host, $usuario, $senha, $bd) or die ("Não foi possível conectar");


?>