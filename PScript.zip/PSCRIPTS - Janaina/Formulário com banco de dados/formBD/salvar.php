<?php
    include 'config.php'
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $mensagem = $_POST["mensagem"];

    $add = mysqli_query($conexao, "insert into contato (nome, email, mensagem) values ('$nome', '$email', '$mensagem')") or print(mysqli_error());

    if($add == 1)
    {
        echo "Inserção feita com sucesso";
        
    }
    else
    {
        echo "Erro. cê e burro cara!";
    }
?>

</body>
</html>