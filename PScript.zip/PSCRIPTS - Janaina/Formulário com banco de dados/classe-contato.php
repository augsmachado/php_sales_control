<?php

	class Contato{
		private $id;
		private $nome;
		private $email;
		private $mensagem;

		public function setNome($nome){
				$this->nome = $nome;
			}

		public function getNome(){
				return $this->nome;
			}
			
		public function salvar($conexao, $nome,
		$email, $msg){
			mysqli_query($conexao,"insert into contato (nome, email, mensagem) values
			('$nome','$email','$msg')") 
			or print (mysqli_error());
			return 1;
		}	

		public function listar($conexao)
		{
				$sql = mysqli_query($conexao, "SELECT * FROM contato ORDER BY nome asc");
				return $sql;
		}
		
	}

?>