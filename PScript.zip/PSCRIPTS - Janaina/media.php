<?php

/*Exercício
Calculo de média
Crie um formulário html com uma caixa de texto, um select e dois botões
um dos botões para adicionar o valor digitado na caixa de texto no list
o outro botão para calcular a média dos valores
Exiba o calculo na mesma página
*/
?>
<html>

	<head>
		<script>
		
			function add()
			{
				var select = document.getElementById("lista");
				var valor = document.getElementById("valor").value;
				
				var option = new Option(valor, valor);    
				select.add(option);		
				
			}
		</script>
	</head>

<form method="post" action="media.php">

	<label for="valor">Valor</label>
	<input type="text" name="valor" id="valor"/>
	<button type="button" value="adicionar" onclick="add()"> Adiciona </button>
	<br>
	<br><br>
	<label for="lista">Lista de Valores</label><br>
	<select name="lista[]" multiple id="lista">	
	<option value="">Selecione....</option>
	</select>
	<br>
	<br>
	
	<button type="submit" value="calcular">  Calcular </button>
	
	</form>
	
	<?php
	
		$total=0;
		
		if(isset($_POST["lista"]))
		{
			$lista=$_POST["lista"];
			
			for($i=0;$i<count($lista); $i++)
			{
				$total+= $lista[$i];
			}
			
			$media =  $total/count($lista);
			
			echo "Media = $media";
		}
			
	?>
	</body>


</html>



